package com.akustom15.mint.library.data

import android.content.Context
import android.util.Log
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.IOException

object AppFilterCache {
    private var cachedIcons: List<String>? = null
    private var cachedThemedComponents: Set<String>? = null
    
    fun getIconNames(context: Context): List<String> {
        if (cachedIcons != null) {
            return cachedIcons!!
        }
        
        val iconNames = mutableListOf<String>()
        val packageName = context.packageName
        
        try {
            val appfilterResId = context.resources.getIdentifier("appfilter", "xml", packageName)
            if (appfilterResId != 0) {
                parseXml(context, appfilterResId, iconNames)
            }
            
            val appfilterNewResId = context.resources.getIdentifier("appfilter_new", "xml", packageName)
            if (appfilterNewResId != 0) {
                parseXml(context, appfilterNewResId, iconNames)
            }
            
            cachedIcons = iconNames
        } catch (e: Exception) {
            Log.e("AppFilterCache", "Error loading icons from appfilter", e)
        }
        
        return iconNames
    }

    /**
     * Returns the set of themed component strings (packageName/activityName) from appfilter.xml.
     * Used for detecting which apps already have icons.
     */
    fun getThemedComponents(context: Context): Set<String> {
        if (cachedThemedComponents != null) {
            return cachedThemedComponents!!
        }

        val result = mutableSetOf<String>()
        val packageName = context.packageName

        // First try to parse from res/xml/appfilter.xml
        try {
            val resId = context.resources.getIdentifier("appfilter", "xml", packageName)
            if (resId != 0) {
                val parser = context.resources.getXml(resId)
                parseThemedComponents(parser, result)
                parser.close()
            }
        } catch (e: Exception) {
            Log.e("AppFilterCache", "Error parsing res/xml/appfilter.xml", e)
        }

        // Then also try to parse from assets/appfilter.xml
        try {
            val inputStream = context.assets.open("appfilter.xml")
            val factory = org.xmlpull.v1.XmlPullParserFactory.newInstance()
            factory.isNamespaceAware = true
            val parser = factory.newPullParser()
            parser.setInput(inputStream, null)
            parseThemedComponents(parser, result)
            inputStream.close()
        } catch (e: Exception) {
            // Ignore if assets/appfilter.xml does not exist
        }

        cachedThemedComponents = result
        return result
    }

    private fun parseThemedComponents(parser: XmlPullParser, result: MutableSet<String>) {
        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && parser.name == "item") {
                val componentString = parser.getAttributeValue(null, "component")
                if (componentString != null &&
                    componentString.startsWith("ComponentInfo{") &&
                    componentString.endsWith("}")
                ) {
                    val fullComponent = componentString.substring(
                        "ComponentInfo{".length,
                        componentString.length - 1
                    )
                    if (fullComponent.isNotBlank() && fullComponent.contains("/") && !fullComponent.contains(" ")) {
                        result.add(fullComponent.lowercase().trim())
                    }
                }
            }
            eventType = parser.next()
        }
    }
    
    private fun parseXml(context: Context, resId: Int, iconNames: MutableList<String>) {
        var parser = context.resources.getXml(resId)
        try {
            var eventType = parser.eventType
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG && parser.name == "item") {
                    for (i in 0 until parser.attributeCount) {
                        if (parser.getAttributeName(i) == "drawable") {
                            parser.getAttributeValue(i)?.let { iconNames.add(it) }
                        }
                    }
                }
                eventType = parser.next()
            }
        } finally {
            parser.close()
        }
    }
    
    fun clearCache() {
        cachedIcons = null
        cachedThemedComponents = null
    }
}
